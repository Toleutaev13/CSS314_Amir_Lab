#!/usr/bin/env python3
"""Milestone 3 - strong/weak scaling of a 5-point Jacobi stencil + Roofline.

Strong: fixed N (salted), P = 1,2,4,.. up to physical cores.
Weak:   N_P = ceil(N*sqrt(P)).
Outputs: results/scaling_metrics.tsv, results/roofline_summary.json
"""
import argparse
import json
import math
import multiprocessing as mp
import os
import statistics
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np

from salt import get_student_params

ROOT = Path(__file__).resolve().parent.parent
ITERS = 100
REPEATS = 3
_G = {}


# ------------------------------------------------------------------ kernel
def _init(raw_a, raw_b, n):
    _G["A"] = np.frombuffer(raw_a, dtype=np.float64).reshape(n, n)
    _G["B"] = np.frombuffer(raw_b, dtype=np.float64).reshape(n, n)


def stencil_rows(src, dst, r0, r1):
    dst[r0:r1, 1:-1] = 0.25 * (src[r0 - 1:r1 - 1, 1:-1] + src[r0 + 1:r1 + 1, 1:-1]
                               + src[r0:r1, :-2] + src[r0:r1, 2:])


def _task(args):
    a_is_src, r0, r1 = args
    src, dst = (_G["A"], _G["B"]) if a_is_src else (_G["B"], _G["A"])
    stencil_rows(src, dst, r0, r1)


def run_stencil(n, P, seed, iters=ITERS):
    """Return (elapsed_s, result_array). P == 1 runs inline (true serial baseline)."""
    raw_a = mp.RawArray("d", n * n)
    raw_b = mp.RawArray("d", n * n)
    A = np.frombuffer(raw_a, dtype=np.float64).reshape(n, n)
    B = np.frombuffer(raw_b, dtype=np.float64).reshape(n, n)
    A[:] = np.random.default_rng(seed).random((n, n))
    B[:] = A                                   # identical fixed boundaries

    bounds = np.array_split(np.arange(1, n - 1), P)
    chunks = [(int(c[0]), int(c[-1]) + 1) for c in bounds]

    if P == 1:
        t0 = time.perf_counter()
        for it in range(iters):
            src, dst = (A, B) if it % 2 == 0 else (B, A)
            stencil_rows(src, dst, 1, n - 1)
        elapsed = time.perf_counter() - t0
    else:
        with Pool(P, initializer=_init, initargs=(raw_a, raw_b, n)) as pool:
            t0 = time.perf_counter()
            for it in range(iters):
                pool.map(_task, [(it % 2 == 0, r0, r1) for r0, r1 in chunks],
                         chunksize=1)
            elapsed = time.perf_counter() - t0

    result = A if iters % 2 == 0 else B
    return elapsed, result.copy()


def timed_median(n, P, seed):
    ts, res = [], None
    for _ in range(REPEATS):
        t, res = run_stencil(n, P, seed)
        ts.append(t)
    return statistics.median(ts), res


# ------------------------------------------------------------------ helpers
def load_params(student_id):
    if student_id:
        return get_student_params(student_id)
    return json.loads((ROOT / "results" / "salted_params.json").read_text())


def load_host():
    p = ROOT / "results" / "host_profile.json"
    return json.loads(p.read_text()) if p.exists() else {}


def p_values(max_p):
    ps, p = [], 1
    while p <= max_p:
        ps.append(p)
        p *= 2
    if ps[-1] != max_p:
        ps.append(max_p)
    return ps


def measure_bandwidth_gbs():
    """Single-process copy bandwidth (read + write) on arrays far larger than L3."""
    a = np.ones(32_000_000)
    b = np.empty_like(a)
    best = 0.0
    for _ in range(5):
        t0 = time.perf_counter()
        np.copyto(b, a)
        dt = time.perf_counter() - t0
        best = max(best, 2 * a.nbytes / dt / 1e9)
    return best


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--student-id", default=None)
    ap.add_argument("--max-p", type=int, default=None,
                    help="override max worker count (default: physical cores)")
    ap.add_argument("--mem-mts", type=float, default=3200,
                    help="DRAM transfer rate in MT/s (e.g. DDR4-3200 = 3200)")
    ap.add_argument("--mem-channels", type=int, default=2)
    ap.add_argument("--flops-per-cycle", type=int, default=16,
                    help="FP64 FLOPs/cycle/core: 16 = AVX2+FMA, 32 = AVX-512")
    ap.add_argument("--freq-ghz", type=float, default=None)
    args = ap.parse_args()

    params = load_params(args.student_id)
    host = load_host()
    N, seed = params["N"], params["seed"]

    max_p = args.max_p or host.get("physical_core_count") or os.cpu_count() or 1
    plist = p_values(max_p)
    print(f"N={N}  seed={seed}  iters={ITERS}  P values={plist}")

    rows = []

    # ---- strong scaling
    t1 = None
    ref_sum = None
    strong = []
    for P in plist:
        T, res = timed_median(N, P, seed)
        if P == 1:
            t1, ref_sum = T, float(res.sum())
        S = t1 / T
        E = S / P * 100
        s_est = (1 / S - 1 / P) / (1 - 1 / P) if P > 1 else float("nan")
        ck = float(res.sum())
        ok = ck == ref_sum
        strong.append((P, S, s_est))
        rows.append(("strong", P, N, N * N, T, S, E, s_est, ck, ok))
        print(f"strong P={P:<2} T={T:7.3f}s  S={S:5.2f}  E={E:6.1f}%  "
              f"s={s_est:6.3f}  checksum_ok={ok}")

    # least-squares Amdahl fit over P>1:  y=1/S, x=1/P, y-x = s(1-x)
    pts = [(1 / P, 1 / S) for P, S, _ in strong if P > 1]
    if pts:
        s_fit = sum((y - x) * (1 - x) for x, y in pts) / sum((1 - x) ** 2 for x, _ in pts)
        s_fit = max(s_fit, 1e-9)
    else:
        s_fit = float("nan")
    s_max = 1 / s_fit if s_fit == s_fit else float("nan")
    print(f"\nAmdahl fit: s = {s_fit:.4f}   S_max = 1/s = {s_max:.2f}")

    # ---- weak scaling
    weak_t1 = None
    for P in plist:
        nP = math.ceil(N * math.sqrt(P))
        T, res = timed_median(nP, P, seed)
        if P == 1:
            weak_t1 = T
            ref = float(res.sum())
        else:
            _, ref_arr = run_stencil(nP, 1, seed)         # untimed serial reference
            ref = float(ref_arr.sum())
        work_ratio = (nP * nP) / (N * N)
        S_scaled = work_ratio * weak_t1 / T               # Gustafson scaled speedup
        E = S_scaled / P * 100
        alpha = (P - S_scaled) / (P - 1) if P > 1 else float("nan")
        ck = float(res.sum())
        ok = ck == ref
        rows.append(("weak", P, nP, nP * nP, T, S_scaled, E, alpha, ck, ok))
        print(f"weak   P={P:<2} N={nP:<5} T={T:7.3f}s  S_scaled={S_scaled:5.2f}  "
              f"E={E:6.1f}%  alpha={alpha:6.3f}  checksum_ok={ok}")

    out = ROOT / "results" / "scaling_metrics.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        f.write("study\tP\tN\tgrid_points\ttime_s_median\tspeedup\tefficiency_pct\t"
                "serial_fraction_est\tchecksum\tchecksum_match_serial\n")
        for r in rows:
            f.write(f"{r[0]}\t{r[1]}\t{r[2]}\t{r[3]}\t{r[4]:.6f}\t{r[5]:.4f}\t"
                    f"{r[6]:.2f}\t{r[7]:.5f}\t{r[8]!r}\t{r[9]}\n")
    print(f"Saved: {out}")

    # ---- roofline
    freq_hz = (args.freq_ghz * 1e9 if args.freq_ghz else host.get("base_frequency_hz"))
    cores = host.get("physical_core_count") or max_p
    peak_flops = freq_hz * cores * args.flops_per_cycle if freq_hz else None
    peak_bw = args.mem_mts * 1e6 * 8 * args.mem_channels          # bytes/s
    meas_bw = measure_bandwidth_gbs() * 1e9

    flops_per_point = 4                       # 3 adds + 1 multiply
    bytes_ideal = 16                          # 8 B read (neighbours reused) + 8 B write
    bytes_wa = 24                             # + write-allocate read of destination line
    ai_ideal = flops_per_point / bytes_ideal
    ai_wa = flops_per_point / bytes_wa

    working_set = 2 * N * N * 8
    l2, l3 = host.get("l2_cache_size_bytes"), host.get("l3_shared_cache_size_bytes")
    ridge = peak_flops / peak_bw if peak_flops else None
    regime = ("memory-bandwidth bound" if (ridge is None or ai_ideal < ridge)
              else "compute bound")

    summary = {
        "student_id": params["student_id"],
        "N": N,
        "kernel": "5-point Jacobi stencil, float64, 100 sweeps",
        "flops_per_grid_point": flops_per_point,
        "dram_bytes_per_grid_point_ideal": bytes_ideal,
        "dram_bytes_per_grid_point_with_write_allocate": bytes_wa,
        "arithmetic_intensity_flop_per_byte": ai_ideal,
        "arithmetic_intensity_with_write_allocate": ai_wa,
        "working_set_bytes": working_set,
        "l2_cache_size_bytes": l2,
        "l3_shared_cache_size_bytes": l3,
        "working_set_exceeds_l3": (working_set > l3) if l3 else None,
        "assumptions": {
            "mem_mts": args.mem_mts,
            "mem_channels": args.mem_channels,
            "flops_per_cycle_per_core": args.flops_per_cycle,
            "frequency_hz": freq_hz,
            "physical_cores": cores,
        },
        "peak_memory_bandwidth_theoretical_GBps": peak_bw / 1e9,
        "memory_bandwidth_measured_1proc_copy_GBps": meas_bw / 1e9,
        "peak_fp64_GFLOPs_theoretical": peak_flops / 1e9 if peak_flops else None,
        "ridge_point_flop_per_byte": ridge,
        "roofline_attainable_GFLOPs": (min(peak_flops, ai_ideal * peak_bw) / 1e9
                                       if peak_flops else ai_ideal * peak_bw / 1e9),
        "regime": regime,
        "scaling_fit": {"amdahl_serial_fraction_s": s_fit, "s_max": s_max},
        "conclusion": (
            f"AI = {ai_ideal:.3f} FLOP/B is below the ridge point "
            f"({ridge:.2f} FLOP/B), so the stencil is {regime}."
            if ridge else f"AI = {ai_ideal:.3f} FLOP/B; {regime} (peak FLOPs unknown)."
        ),
    }
    rp = ROOT / "results" / "roofline_summary.json"
    rp.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(f"Saved: {rp}\n{summary['conclusion']}")


if __name__ == "__main__":
    main()
