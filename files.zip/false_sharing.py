#!/usr/bin/env python3
"""Milestone 2 - false sharing, remediation, Karp-Flatt.

Variants (each worker p increments its own counter K times):
  unpadded   - counters at base+p        (all on ONE 64-byte cache line)
  padded     - counters at base+p*8      (one cache line per worker)
  privatized - local scalar, one shared write at the end
The shared buffer is aligned to a 64-byte boundary so "same line" really holds.

Engines:
  python - plain CPython loop (interpreter overhead ~250 ns/iter can HIDE the effect)
  numba  - same loop compiled to machine code (~1-2 ns/iter), so cache-line
           ping-pong dominates. Default if numba is installed.
Output: results/false_sharing_karp_flatt.tsv
"""
import argparse
import ctypes
import multiprocessing as mp
import statistics
import time
from pathlib import Path

import numpy as np

try:
    from numba import njit
    HAVE_NUMBA = True
except ImportError:
    HAVE_NUMBA = False

ROOT = Path(__file__).resolve().parent.parent
P_LIST = [1, 2, 4, 8]
VARIANTS = ["unpadded", "padded", "privatized"]


if HAVE_NUMBA:
    @njit(nogil=True, cache=True)
    def inc_loop(arr, idx, iters):
        for _ in range(iters):
            # the index depends on the loaded value (always +0) so the compiler
            # cannot keep the counter in a register: every iteration really
            # loads and stores the shared cache line
            j = idx + (arr[idx] >> 62)
            arr[j] += 1

    @njit(nogil=True, cache=True)
    def private_loop(arr, idx, iters):
        local = 0
        for _ in range(iters):
            local += 1 + (local >> 62)     # opaque to constant folding
        arr[idx] = local                   # single write at the end


def worker(mode, engine, shared, base, p, iters, barrier, times):
    idx = base + (p * 8 if mode == "padded" else p)

    if engine == "numba":
        arr = np.frombuffer(shared, dtype=np.int64)
        dummy = np.zeros(2, dtype=np.int64)
        inc_loop(dummy, 0, 1)              # compile / load cache before timing
        private_loop(dummy, 0, 1)
        barrier.wait()
        t0 = time.perf_counter_ns()
        if mode == "privatized":
            private_loop(arr, idx, iters)
        else:
            inc_loop(arr, idx, iters)
    else:
        barrier.wait()
        t0 = time.perf_counter_ns()
        if mode == "privatized":
            local = 0
            for _ in range(iters):
                local += 1
            shared[idx] = local
        else:
            for _ in range(iters):
                shared[idx] += 1
    times[p] = time.perf_counter_ns() - t0


def run_once(mode, engine, P, K):
    shared = mp.RawArray(ctypes.c_int64, 80)         # 64 slots + alignment slack
    times = mp.RawArray(ctypes.c_int64, 8)
    base = ((-ctypes.addressof(shared)) % 64) // 8   # first index on a 64B boundary
    barrier = mp.Barrier(P)

    procs = [mp.Process(target=worker,
                        args=(mode, engine, shared, base, p, K, barrier, times))
             for p in range(P)]
    for pr in procs:
        pr.start()
    for pr in procs:
        pr.join()

    stride = 8 if mode == "padded" else 1
    total = sum(shared[base + p * stride] for p in range(P))
    return max(times[p] for p in range(P)) / 1e9, total


def karp_flatt(S, P):
    return (1 / S - 1 / P) / (1 - 1 / P)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", choices=["python", "numba"],
                    default="numba" if HAVE_NUMBA else "python")
    ap.add_argument("--K", type=int, default=None,
                    help="iterations per worker (default 5,000,000 python / "
                         "50,000,000 numba)")
    ap.add_argument("--repeats", type=int, default=3)
    args = ap.parse_args()

    if args.engine == "numba" and not HAVE_NUMBA:
        raise SystemExit("numba is not installed: python -m pip install numba")
    K = args.K or (50_000_000 if args.engine == "numba" else 5_000_000)
    print(f"engine={args.engine}  K={K}  repeats={args.repeats}")

    rows = []
    for mode in VARIANTS:
        t1 = None
        for P in P_LIST:
            runs, ok = [], True
            for _ in range(args.repeats):
                t, total = run_once(mode, args.engine, P, K)
                runs.append(t)
                ok &= (total == P * K)
            T = statistics.median(runs)
            if P == 1:
                t1 = T

            s_lit = t1 / T                       # handout formula (same K per worker)
            s_scaled = P * t1 / T                # work-normalised, ideal = P
            if P > 1:
                e_lit = (P * T / t1 - 1) / (P - 1)
                e_scaled = karp_flatt(s_scaled, P)
            else:
                e_lit = e_scaled = float("nan")

            rows.append((mode, P, K, T, s_lit, e_lit, s_scaled, e_scaled, P * K, ok))
            print(f"{mode:<10} P={P}  T={T:8.3f}s  S_scaled={s_scaled:5.2f}  "
                  f"e_scaled={e_scaled:6.3f}  count_ok={ok}")

    out = ROOT / "results" / "false_sharing_karp_flatt.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        f.write("variant\tP\tK_per_worker\ttime_s_median\tspeedup_literal_T1_over_TP\t"
                "karp_flatt_literal\tspeedup_scaled_P_T1_over_TP\tkarp_flatt_scaled\t"
                "expected_total\tcount_exact\tengine\n")
        for r in rows:
            f.write("\t".join(
                [r[0], str(r[1]), str(r[2]), f"{r[3]:.6f}", f"{r[4]:.4f}",
                 f"{r[5]:.4f}", f"{r[6]:.4f}", f"{r[7]:.4f}", str(r[8]), str(r[9]),
                 args.engine]) + "\n")
    print(f"\nSaved: {out}")


if __name__ == "__main__":
    main()
