
#!/usr/bin/env python3

import argparse
import json
import os
import platform
import re
import subprocess
import sys
from pathlib import Path

from salt import get_student_params


def run_command(command):
    try:
        return subprocess.check_output(
            command,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def parse_size(value):
    """Convert values such as 32K, 512K, 16M or 32768 to bytes."""
    if value is None:
        return None

    text = str(value).strip().replace(" ", "")

    try:
        return int(text)
    except ValueError:
        pass

    match = re.fullmatch(
        r"([0-9]+(?:\.[0-9]+)?)([KMGT]?)(?:I?B)?",
        text,
        flags=re.IGNORECASE,
    )

    if not match:
        return None

    number = float(match.group(1))
    suffix = match.group(2).upper()

    multiplier = {
        "": 1,
        "K": 1024,
        "M": 1024**2,
        "G": 1024**3,
        "T": 1024**4,
    }[suffix]

    return int(number * multiplier)


def frequency_from_model(model_name):
    """Extract base frequency from names such as 'CPU @ 2.40GHz'."""
    match = re.search(
        r"@\s*([0-9]+(?:\.[0-9]+)?)\s*([GM])Hz",
        model_name,
        flags=re.IGNORECASE,
    )

    if not match:
        return None

    value = float(match.group(1))
    unit = match.group(2).upper()

    return int(value * (1_000_000_000 if unit == "G" else 1_000_000))


def detect_microarchitecture(vendor, family, model):
    try:
        family = int(family)
        model = int(model)
    except (TypeError, ValueError):
        return "Unknown"

    if vendor == "GenuineIntel" and family == 6:
        intel_models = {
            42: "Sandy Bridge",
            58: "Ivy Bridge",
            60: "Haswell",
            63: "Haswell",
            69: "Haswell",
            70: "Haswell",
            61: "Broadwell",
            71: "Broadwell",
            79: "Broadwell",
            86: "Broadwell",
            78: "Skylake",
            94: "Skylake",
            142: "Kaby Lake / Coffee Lake",
            158: "Kaby Lake / Coffee Lake",
            165: "Comet Lake",
            166: "Comet Lake",
            140: "Tiger Lake",
            141: "Tiger Lake",
            151: "Alder Lake",
            154: "Alder Lake",
            183: "Raptor Lake",
            186: "Raptor Lake",
            170: "Meteor Lake",
            189: "Lunar Lake",
        }

        if model in intel_models:
            return intel_models[model]

    if vendor == "AuthenticAMD":
        if family == 23:
            return "Zen / Zen+ / Zen 2"
        if family == 25:
            return "Zen 3 / Zen 4"
        if family == 26:
            return "Zen 5"

    return f"Unknown (CPU family {family}, model {model})"


def linux_profile():
    cpuinfo_path = Path("/proc/cpuinfo")
    cpuinfo = (
        cpuinfo_path.read_text(errors="replace")
        if cpuinfo_path.exists()
        else ""
    )

    def cpuinfo_field(name):
        match = re.search(
            rf"^{re.escape(name)}\s*:\s*(.+)$",
            cpuinfo,
            flags=re.MULTILINE,
        )
        return match.group(1).strip() if match else None

    model_name = (
        cpuinfo_field("model name")
        or cpuinfo_field("Hardware")
        or platform.processor()
        or "Unknown CPU"
    )

    vendor = cpuinfo_field("vendor_id")
    family = cpuinfo_field("cpu family")
    model_number = cpuinfo_field("model")

    physical_cores = None

    lscpu_output = run_command(["lscpu"])
    lscpu = {}

    for line in lscpu_output.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            lscpu[key.strip()] = value.strip()

    try:
        sockets = int(lscpu["Socket(s)"])
        cores_per_socket = int(lscpu["Core(s) per socket"])
        physical_cores = sockets * cores_per_socket
    except (KeyError, ValueError):
        pass

    if physical_cores is None:
        core_pairs = set()
        physical_id = None
        core_id = None

        for line in cpuinfo.splitlines() + [""]:
            if not line.strip():
                if physical_id is not None and core_id is not None:
                    core_pairs.add((physical_id, core_id))

                physical_id = None
                core_id = None
                continue

            if line.startswith("physical id"):
                physical_id = line.split(":", 1)[1].strip()
            elif line.startswith("core id"):
                core_id = line.split(":", 1)[1].strip()

        physical_cores = len(core_pairs) or None

    caches = {
        "l1_data_cache_size_bytes": None,
        "l2_cache_size_bytes": None,
        "l3_shared_cache_size_bytes": None,
        "cache_line_size_bytes": None,
    }

    cache_root = Path("/sys/devices/system/cpu/cpu0/cache")

    if cache_root.exists():
        for index_path in sorted(cache_root.glob("index*")):
            try:
                level = int((index_path / "level").read_text().strip())
                cache_type = (index_path / "type").read_text().strip()
                size = parse_size((index_path / "size").read_text().strip())
                line_size = int(
                    (index_path / "coherency_line_size").read_text().strip()
                )
            except (OSError, ValueError):
                continue

            if level == 1 and cache_type == "Data":
                caches["l1_data_cache_size_bytes"] = size
            elif level == 2:
                caches["l2_cache_size_bytes"] = size
            elif level == 3:
                caches["l3_shared_cache_size_bytes"] = size

            caches["cache_line_size_bytes"] = line_size

    base_frequency_hz = frequency_from_model(model_name)

    base_frequency_path = Path(
        "/sys/devices/system/cpu/cpu0/cpufreq/base_frequency"
    )

    if base_frequency_hz is None and base_frequency_path.exists():
        try:
            base_frequency_hz = (
                int(base_frequency_path.read_text().strip()) * 1000
            )
        except (OSError, ValueError):
            pass

    return {
        "cpu_model_name": model_name,
        "microarchitecture": detect_microarchitecture(
            vendor,
            family,
            model_number,
        ),
        "base_frequency_hz": base_frequency_hz,
        "physical_core_count": physical_cores,
        **caches,
    }


def macos_profile():
    def sysctl(name):
        value = run_command(["sysctl", "-n", name])
        return value or None

    def sysctl_int(name):
        value = sysctl(name)
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    model_name = sysctl("machdep.cpu.brand_string") or platform.processor()

    return {
        "cpu_model_name": model_name,
        "microarchitecture": (
            "Apple Silicon"
            if platform.machine().lower() in {"arm64", "aarch64"}
            else "See CPU model name"
        ),
        "base_frequency_hz": frequency_from_model(model_name),
        "physical_core_count": sysctl_int("hw.physicalcpu"),
        "l1_data_cache_size_bytes": sysctl_int("hw.l1dcachesize"),
        "l2_cache_size_bytes": sysctl_int("hw.l2cachesize"),
        "l3_shared_cache_size_bytes": sysctl_int("hw.l3cachesize"),
        "cache_line_size_bytes": sysctl_int("hw.cachelinesize"),
    }


def windows_profile():
    def ps(prop):
        return run_command([
            "powershell", "-NoProfile", "-Command",
            f"(Get-CimInstance Win32_Processor | Select-Object -First 1).{prop}",
        ])

    def ps_int(prop):
        try:
            return int(ps(prop))
        except ValueError:
            return None

    raw = platform.processor() or ""
    model_name = ps("Name") or raw or "Unknown CPU"

    match = re.search(r"Family\s+(\d+)\s+Model\s+(\d+)", raw)
    vendor = (
        "GenuineIntel" if "GenuineIntel" in raw
        else "AuthenticAMD" if "AuthenticAMD" in raw
        else None
    )
    arch = (
        detect_microarchitecture(vendor, match.group(1), match.group(2))
        if match else "Unknown"
    )

    max_mhz = ps_int("MaxClockSpeed")
    l2_kb = ps_int("L2CacheSize")      # reported in KB (total for the package)
    l3_kb = ps_int("L3CacheSize")

    return {
        "cpu_model_name": model_name,
        "microarchitecture": arch,
        "base_frequency_hz": (
            frequency_from_model(model_name)
            or (max_mhz * 1_000_000 if max_mhz else None)
        ),
        "physical_core_count": ps_int("NumberOfCores"),
        "l1_data_cache_size_bytes": None,   # not exposed by WMI: fill in manually
        "l2_cache_size_bytes": l2_kb * 1024 if l2_kb else None,
        "l3_shared_cache_size_bytes": l3_kb * 1024 if l3_kb else None,
        "cache_line_size_bytes": 64,
    }


def collect_host_profile():
    if sys.platform.startswith("linux"):
        profile = linux_profile()
    elif sys.platform == "darwin":
        profile = macos_profile()
    elif os.name == "nt":
        profile = windows_profile()
    else:
        profile = {
            "cpu_model_name": platform.processor(),
            "microarchitecture": "Unknown",
            "base_frequency_hz": None,
            "physical_core_count": None,
            "l1_data_cache_size_bytes": None,
            "l2_cache_size_bytes": None,
            "l3_shared_cache_size_bytes": None,
            "cache_line_size_bytes": None,
        }

    logical_threads = os.cpu_count()
    physical_cores = profile.get("physical_core_count")

    profile.update(
        {
            "logical_thread_count": logical_threads,
            "smt_enabled": (
                logical_threads > physical_cores
                if logical_threads and physical_cores
                else None
            ),
            "os_platform": platform.platform(),
            "os_kernel_version": platform.release(),
            "python_implementation": platform.python_implementation(),
            "python_version": platform.python_version(),
            "python_compiler": platform.python_compiler(),
        }
    )

    # alias expected by verify_outputs.py
    profile["cpu_model"] = profile["cpu_model_name"]

    return profile


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--student-id",
        default="230103142",
        help="Your student ID",
    )

    args = parser.parse_args()

    if not re.fullmatch(r"[0-9]{9}", args.student_id):
        parser.error("Student ID must contain exactly 9 digits")

    results_dir = Path("results")
    results_dir.mkdir(parents=True, exist_ok=True)

    host_profile = collect_host_profile()
    salted_params = get_student_params(args.student_id)

    host_path = results_dir / "host_profile.json"
    params_path = results_dir / "salted_params.json"

    host_path.write_text(
        json.dumps(host_profile, indent=2) + "\n",
        encoding="utf-8",
    )

    params_path.write_text(
        json.dumps(salted_params, indent=2) + "\n",
        encoding="utf-8",
    )

    print(f"Saved: {host_path}")
    print(json.dumps(host_profile, indent=2))

    print(f"\nSaved: {params_path}")
    print(json.dumps(salted_params, indent=2))


if __name__ == "__main__":
    main()
