#!/usr/bin/env python3
"""Milestone 1.1 - stride latency cliff benchmark.

Reads a 2^24-element float64 array (~134 MB, larger than L3) with strides
1,2,4,...,128 and reports the median time per element touched.
Output: results/stride_results.tsv
"""
import statistics
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
N_ELEMENTS = 16_777_216
STRIDES = [1, 2, 4, 8, 16, 32, 64, 128]
WARMUP = 5
RUNS = 5


def traverse(data, stride):
    # total += data[i] for i in range(0, n, stride), done as a strided reduction
    return np.add.reduce(data[::stride])


def main():
    data = np.ones(N_ELEMENTS, dtype=np.float64)
    rows = []

    for s in STRIDES:
        touched = len(range(0, N_ELEMENTS, s))

        for _ in range(WARMUP):
            traverse(data, s)

        times = []
        for _ in range(RUNS):
            t0 = time.perf_counter_ns()
            total = traverse(data, s)
            times.append(time.perf_counter_ns() - t0)

        assert total == touched, "reduction result is wrong"
        med = int(statistics.median(times))
        rows.append((s, s * 8, touched, med, med / touched))

    base = rows[0][4]
    out = ROOT / "results" / "stride_results.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w", encoding="utf-8") as f:
        f.write("stride_elements\tstride_bytes\telements_touched\t"
                "median_time_ns\tlatency_per_element_ns\tslowdown_vs_stride1\n")
        for s, sb, touched, med, lat in rows:
            f.write(f"{s}\t{sb}\t{touched}\t{med}\t{lat:.4f}\t{lat / base:.3f}\n")

    print(f"{'stride':>6} {'ns/elem':>10} {'x vs s=1':>9}")
    for s, _, _, _, lat in rows:
        print(f"{s:>6} {lat:>10.3f} {lat / base:>9.2f}")
    print(f"\nSaved: {out}")


if __name__ == "__main__":
    main()
