#!/usr/bin/env python3
"""Milestone 1.2 - loop interchange i-j-k vs i-k-j on a sub-block M = N/2.

Engines:
  numba  - real scalar triple loops compiled by Numba (best, shows true cache effect)
  numpy  - Python loops over i,j (naive) / i,k (interchanged) with NumPy on the
           innermost loop (column dot product vs. contiguous row update)
  python - pure Python loops on flat lists (very slow; use --M to shrink)
Output: results/loop_interchange.json
"""
import argparse
import hashlib
import json
import statistics
import time
from pathlib import Path

import numpy as np

from salt import get_student_params

ROOT = Path(__file__).resolve().parent.parent
RUNS = 3

try:
    from numba import njit
    HAVE_NUMBA = True
except ImportError:
    HAVE_NUMBA = False


if HAVE_NUMBA:
    @njit(cache=True)
    def ijk_numba(A, B, C, N, M):
        for i in range(M):
            for j in range(M):
                acc = 0.0
                for k in range(M):
                    acc += A[i * N + k] * B[k * N + j]   # B strides by N
                C[i * N + j] = acc

    @njit(cache=True)
    def ikj_numba(A, B, C, N, M):
        for i in range(M):
            for k in range(M):
                a = A[i * N + k]                         # hoisted
                for j in range(M):
                    C[i * N + j] += a * B[k * N + j]     # stride-1


def ijk_numpy(A, B, C, N, M):
    A2, B2, C2 = A.reshape(N, N), B.reshape(N, N), C.reshape(N, N)
    for i in range(M):
        row = A2[i, :M]
        for j in range(M):
            C2[i, j] = np.dot(row, B2[:M, j])            # column access, stride N


def ikj_numpy(A, B, C, N, M):
    A2, B2, C2 = A.reshape(N, N), B.reshape(N, N), C.reshape(N, N)
    for i in range(M):
        ci = C2[i, :M]
        for k in range(M):
            ci += A2[i, k] * B2[k, :M]                   # contiguous row


def ijk_python(A, B, C, N, M):
    for i in range(M):
        for j in range(M):
            acc = 0.0
            for k in range(M):
                acc += A[i * N + k] * B[k * N + j]
            C[i * N + j] = acc


def ikj_python(A, B, C, N, M):
    for i in range(M):
        for k in range(M):
            a = A[i * N + k]
            for j in range(M):
                C[i * N + j] += a * B[k * N + j]


def timed(fn, A, B, N, M, make_c):
    times, last = [], None
    for _ in range(RUNS):
        C = make_c()
        t0 = time.perf_counter_ns()
        fn(A, B, C, N, M)
        times.append(time.perf_counter_ns() - t0)
        last = C
    return int(statistics.median(times)), times, last


def block(C, N, M):
    return np.asarray(C, dtype=np.float64).reshape(N, N)[:M, :M]


def digest(mat):
    return hashlib.sha256(np.round(mat, 6).tobytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--student-id", default=None)
    ap.add_argument("--engine", choices=["auto", "numba", "numpy", "python"],
                    default="auto")
    ap.add_argument("--M", type=int, default=None, help="override sub-block size")
    args = ap.parse_args()

    if args.student_id:
        params = get_student_params(args.student_id)
    else:
        params = json.loads((ROOT / "results" / "salted_params.json").read_text())

    N, seed = params["N"], params["seed"]
    M = args.M or N // 2

    engine = args.engine
    if engine == "auto":
        engine = "numba" if HAVE_NUMBA else "numpy"
    if engine == "numba" and not HAVE_NUMBA:
        raise SystemExit("numba is not installed: pip install numba")

    rng = np.random.default_rng(seed)
    A = rng.random(N * N)          # flat row-major buffers
    B = rng.random(N * N)
    ref = A.reshape(N, N)[:M, :M] @ B.reshape(N, N)[:M, :M]

    if engine == "numba":
        f_naive, f_swap = ijk_numba, ikj_numba
        make_c = lambda: np.zeros(N * N)
        z = np.zeros(4 * 4)
        f_naive(np.ones(16), np.ones(16), z, 4, 4)       # compile outside timing
        f_swap(np.ones(16), np.ones(16), z, 4, 4)
    elif engine == "numpy":
        f_naive, f_swap = ijk_numpy, ikj_numpy
        make_c = lambda: np.zeros(N * N)
    else:
        f_naive, f_swap = ijk_python, ikj_python
        A, B = A.tolist(), B.tolist()
        make_c = lambda: [0.0] * (N * N)

    print(f"N={N}  M={M}  engine={engine}  runs={RUNS}")
    t_naive, naive_runs, C1 = timed(f_naive, A, B, N, M, make_c)
    print(f"i-j-k median: {t_naive / 1e9:.3f} s")
    t_swap, swap_runs, C2 = timed(f_swap, A, B, N, M, make_c)
    print(f"i-k-j median: {t_swap / 1e9:.3f} s")

    C1b, C2b = block(C1, N, M), block(C2, N, M)
    diff_naive = float(np.max(np.abs(C1b - ref)))
    diff_swap = float(np.max(np.abs(C2b - ref)))
    diff_between = float(np.max(np.abs(C1b - C2b)))
    tol = 1e-12 * max(1.0, float(np.max(np.abs(ref))))   # relative to magnitude of C

    result = {
        "student_id": params["student_id"],
        "N": N,
        "M": M,
        "engine": engine,
        "runs": RUNS,
        "t_ijk_median_ns": t_naive,
        "t_ikj_median_ns": t_swap,
        "t_ijk_runs_ns": naive_runs,
        "t_ikj_runs_ns": swap_runs,
        "speedup_ijk_over_ikj": t_naive / t_swap,
        "max_abs_diff_ijk_vs_reference": diff_naive,
        "max_abs_diff_ikj_vs_reference": diff_swap,
        "max_abs_diff_ijk_vs_ikj": diff_between,
        "tolerance_used": tol,
        "numerically_equivalent": bool(diff_between <= tol),
        "sha256_rounded_6dp_ikj": digest(C2b),
        "sha256_rounded_6dp_ijk": digest(C1b),
    }

    out = ROOT / "results" / "loop_interchange.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Speedup S = T_naive / T_interchanged = {result['speedup_ijk_over_ikj']:.2f}x")
    print(f"Equivalent within tolerance: {result['numerically_equivalent']}")
    print(f"Saved: {out}")


if __name__ == "__main__":
    main()
